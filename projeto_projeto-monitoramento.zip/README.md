# 📊 Sistema de Monitoramento Econômico

Sistema web para monitoramento de cotações de moedas em tempo real, consumindo a API pública AwesomeAPI, armazenando histórico em MySQL e exibindo gráficos interativos.

## ️ Tecnologias Utilizadas
- **Backend:** PHP 8.0+ (PDO, cURL)
- **Banco de Dados:** MySQL (Hospedado no InfinityFree)
- **Frontend:** HTML5, CSS3, Bootstrap 5, Chart.js
- **IA Copiloto:** Google Gemini

## 📂 Estrutura do Projeto
- `config/`: Conexão com o banco de dados (PDO).
- `api/`: Classe para consumo da API externa via cURL.
- `models/`: Regras de negócio e consultas SQL (Prepared Statements).
- `controllers/`: Controladores que ligam o frontend ao backend.
- `public/`: Interface do usuário, CSS e JavaScript.

## 🚀 Como Executar
1. Importe o `schema.sql` e o `seed.sql` no seu banco MySQL.
2. Configure suas credenciais no arquivo `config/database.php`.
3. Hospede os arquivos em um servidor com suporte a PHP (ex: InfinityFree).

---

## 🤖 Diário do Copiloto (Google Gemini)

### 🎯 O Melhor Prompt Utilizado
> "Atue como um especialista em PHP e MySQL. Crie uma classe `Cotacao` usando PDO que receba dados de uma API externa. Implemente um método para inserir os dados usando Prepared Statements (para evitar SQL Injection) e outro método para gerar um relatório analítico usando as funções de agregação AVG, COUNT e GROUP BY. Explique como o código garante a segurança dos dados."

### 🐛 Alucinação / Erro Identificado
**O que aconteceu:** O Google Gemini sugeriu inicialmente usar a função `mysql_connect()` para conectar ao banco de dados e recomendou concatenar variáveis diretamente na query SQL para filtrar as moedas.
**Como detectamos e corrigimos:** A equipe percebeu que `mysql_connect()` está obsoleta (deprecated) desde o PHP 5.5 e que a concatenação direta abre brechas para **SQL Injection**. Corrigimos o código substituindo por **PDO (PHP Data Objects)** e utilizando **Prepared Statements** (`bindParam`), conforme exigido nas boas práticas de segurança e nos requisitos do projeto.

### 💡 Conceito Aprendido
Aprendemos na prática a diferença entre buscar dados de uma API e persisti-los em um banco local. O Gemini nos explicou que, ao salvar o histórico no MySQL, conseguimos usar funções nativas do banco (como `AVG()` e `GROUP BY`) para criar relatórios analíticos que a API pública não fornecia prontos, otimizando o desempenho da aplicação e reduzindo chamadas externas repetidas (Cache e Otimização).