<?php
class Alerta {
    private $conn;
    private $table = "alertas";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($usuario_id, $moeda, $valor_alvo, $tipo_alerta) {
        $query = "INSERT INTO " . $this->table . 
                 " (usuario_id, moeda, valor_alvo, tipo_alerta) 
                  VALUES (:usuario_id, :moeda, :valor_alvo, :tipo_alerta)";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':usuario_id', $usuario_id);
        $stmt->bindParam(':moeda', $moeda);
        $stmt->bindParam(':valor_alvo', $valor_alvo);
        $stmt->bindParam(':tipo_alerta', $tipo_alerta);
        
        return $stmt->execute();
    }

    public function getPorUsuario($usuario_id) {
        $query = "SELECT * FROM " . $this->table . 
                 " WHERE usuario_id = :usuario_id AND ativo = 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':usuario_id', $usuario_id);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function verificarAlertas($cotacoes) {
        $query = "SELECT a.*, u.nome, u.email 
                  FROM " . $this->table . " a
                  JOIN usuarios u ON a.usuario_id = u.id
                  WHERE a.ativo = 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $alertas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $alertas_disparados = [];
        
        foreach($alertas as $alerta) {
            $moeda = $alerta['moeda'];
            if(isset($cotacoes[$moeda])) {
                $valor_atual = floatval($cotacoes[$moeda]['bid']);
                $valor_alvo = floatval($alerta['valor_alvo']);
                
                if($alerta['tipo_alerta'] === 'abaixo' && $valor_atual <= $valor_alvo) {
                    $alertas_disparados[] = $alerta;
                } elseif($alerta['tipo_alerta'] === 'acima' && $valor_atual >= $valor_alvo) {
                    $alertas_disparados[] = $alerta;
                }
            }
        }
        
        return $alertas_disparados;
    }
}
?>