<?php
class Cotacao {
    private $conn;
    private $table = "cotacoes";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($moeda, $compra, $venda, $variacao) {
        $query = "INSERT INTO " . $this->table . 
                 " (moeda, valor_compra, valor_venda, variacao_pct) 
                  VALUES (:moeda, :compra, :venda, :variacao)";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':moeda', $moeda);
        $stmt->bindParam(':compra', $compra);
        $stmt->bindParam(':venda', $venda);
        $stmt->bindParam(':variacao', $variacao);
        
        return $stmt->execute();
    }

    public function getHistorico($moeda, $limite = 30) {
        $query = "SELECT * FROM " . $this->table . 
                 " WHERE moeda = :moeda
                  ORDER BY data_registro DESC
                  LIMIT :limite";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':moeda', $moeda);
        $stmt->bindParam(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getRelatorio() {
        $query = "SELECT moeda, 
                         AVG(valor_compra) as media_compra,
                         COUNT(*) as total_registros,
                         MIN(valor_compra) as minimo,
                         MAX(valor_compra) as maximo
                  FROM " . $this->table . "
                  GROUP BY moeda
                  ORDER BY media_compra DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTodas() {
        $query = "SELECT * FROM " . $this->table . 
                 " ORDER BY data_registro DESC LIMIT 50";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>