<?php
require_once '../controllers/CotacaoController.php';

$controller = new CotacaoController();
$resultado = $controller->atualizarCotacoes();
$historico = $controller->getHistorico('USD-BRL');
$relatorio = $controller->getRelatorio();
$todas = $controller->getTodas();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitoramento Econômico</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <span class="navbar-brand">📊 Monitoramento Econômico</span>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if($resultado['sucesso']): ?>
            <div class="alert alert-success"><?= $resultado['mensagem'] ?></div>
        <?php else: ?>
            <div class="alert alert-danger"><?= $resultado['mensagem'] ?></div>
        <?php endif; ?>

        <div class="row mb-4">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Histórico USD-BRL</h5>
                        <canvas id="graficoCotacoes"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Relatório Analítico</h5>
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Moeda</th>
                                    <th>Média</th>
                                    <th>Registros</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($relatorio as $item): ?>
                                <tr>
                                    <td><?= $item['moeda'] ?></td>
                                    <td>R$ <?= number_format($item['media_compra'], 2) ?></td>
                                    <td><?= $item['total_registros'] ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Últimas Cotações</h5>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Moeda</th>
                            <th>Compra</th>
                            <th>Venda</th>
                            <th>Variação %</th>
                            <th>Data</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($todas as $cotacao): ?>
                        <tr>
                            <td><?= $cotacao['moeda'] ?></td>
                            <td>R$ <?= number_format($cotacao['valor_compra'], 4) ?></td>
                            <td>R$ <?= number_format($cotacao['valor_venda'], 4) ?></td>
                            <td><?= $cotacao['variacao_pct'] ?>%</td>
                            <td><?= date('d/m/Y H:i', strtotime($cotacao['data_registro'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="js/app.js"></script>
    <script>
        const dadosCotacoes = <?= json_encode($historico) ?>;
        renderizarGrafico(dadosCotacoes);
    </script>
</body>
</html>