<?php
class AwesomeAPI {
    private $url = 'https://economia.awesomeapi.com.br/last/';
    
    public function getCotacoes($moedas = 'USD-BRL,EUR-BRL,BTC-BRL') {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->url . $moedas);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json'
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if(curl_errno($ch)) {
            throw new Exception('Erro cURL: ' . curl_error($ch));
        }
        
        curl_close($ch);
        
        if($httpCode !== 200) {
            throw new Exception("HTTP Error: $httpCode");
        }
        
        return json_decode($response, true);
    }
}
?>