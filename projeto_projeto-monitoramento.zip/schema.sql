CREATE TABLE IF NOT EXISTS usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cotacoes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    moeda VARCHAR(10) NOT NULL,
    valor_compra DECIMAL(10,4) NOT NULL,
    valor_venda DECIMAL(10,4) NOT NULL,
    variacao_pct DECIMAL(5,2),
    data_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_moeda_data (moeda, data_registro)
);

CREATE TABLE IF NOT EXISTS alertas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    moeda VARCHAR(10) NOT NULL,
    valor_alvo DECIMAL(10,4) NOT NULL,
    tipo_alerta ENUM('acima', 'abaixo') NOT NULL,
    ativo BOOLEAN DEFAULT TRUE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);