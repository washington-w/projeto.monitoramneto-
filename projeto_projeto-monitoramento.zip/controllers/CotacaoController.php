<?php
require_once '../config/database.php';
require_once '../api/awesomeapi.php';
require_once '../models/Cotacao.php';

class CotacaoController {
    private $db;
    private $cotacaoModel;
    private $api;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->cotacaoModel = new Cotacao($this->db);
        $this->api = new AwesomeAPI();
    }

    public function atualizarCotacoes() {
        try {
            $dados = $this->api->getCotacoes();
            
            foreach($dados as $moeda => $info) {
                $this->cotacaoModel->create(
                    $moeda,
                    $info['bid'],
                    $info['ask'],
                    $info['pctChange']
                );
            }
            
            return ['sucesso' => true, 'mensagem' => 'Cotações atualizadas!'];
        } catch(Exception $e) {
            return ['sucesso' => false, 'mensagem' => $e->getMessage()];
        }
    }

    public function getHistorico($moeda = 'USD-BRL') {
        return $this->cotacaoModel->getHistorico($moeda);
    }

    public function getRelatorio() {
        return $this->cotacaoModel->getRelatorio();
    }

    public function getTodas() {
        return $this->cotacaoModel->getTodas();
    }
}
?>