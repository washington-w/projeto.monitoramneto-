INSERT INTO usuarios (nome, email, senha_hash) VALUES 
('Aluno Teste', 'aluno@escola.com', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe.YYr3hFZhvvAUaHMvdh6mZDH3gxPLu6');

INSERT INTO cotacoes (moeda, valor_compra, valor_venda, variacao_pct) VALUES 
('USD-BRL', 5.1500, 5.1600, 0.50),
('USD-BRL', 5.1800, 5.1900, 0.60),
('USD-BRL', 5.2000, 5.2100, 0.40),
('EUR-BRL', 5.6500, 5.6700, -0.30),
('EUR-BRL', 5.7000, 5.7200, 0.90),
('BTC-BRL', 250000.0000, 251000.0000, 2.10);

INSERT INTO alertas (usuario_id, moeda, valor_alvo, tipo_alerta) VALUES 
(1, 'USD-BRL', 5.00, 'abaixo');